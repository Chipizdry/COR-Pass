


const deviceId = "COR-B0B21CA3435C";
let axiomaWS = null;

async function startMonitoringAxioma(objectData) {
    const INTERVAL = 1000;
     const INVERTER_MAX_POWER = 11000;
    setDeviceVisibility("Generator", "hidden");

    const protocol = objectData.protocol;

    switch (protocol) {
        case "modbus_over_tcp":
            while (true) {
                console.log("---- Цикл обновления Axioma (TCP) ----");
                await new Promise(r => setTimeout(r, INTERVAL));
            }
            break;

        case "COR-Bridge":
            console.log("🚀 Запуск COR-Bridge WS мониторинга");
            startAxiomaCORBridgeWS(objectData);
            break;

        default:
            console.warn("Неизвестный протокол Axioma:", protocol);
    }
}

function hexToAscii(hex) {
    if (!hex || typeof hex !== "string") return "";

    let result = "";
    for (let i = 0; i < hex.length; i += 2) {
        const byte = parseInt(hex.substr(i, 2), 16);
        if (!isNaN(byte)) {
            result += String.fromCharCode(byte);
        }
    }
    return result;
}

function startAxiomaCORBridgeWS(objectData) {
    const deviceId = "COR-B0B21CA3435C";
    console.log("🚀 Инициализация Axioma COR-Bridge WS", { deviceId });

    if (!deviceId) {
        console.error("❌ device_id не задан для COR-Bridge");
        return;
    }

    const wsUrl = `wss://dev-corid.cor-medical.ua/dev-modbus/responses?device_id=${deviceId}`;
    console.log("🌐 WS URL:", wsUrl);

    if (axiomaWS && axiomaWS.readyState === WebSocket.OPEN) {
        console.warn("⚠️ WS уже запущен");
        return;
    }

    axiomaWS = new WebSocket(wsUrl);

    axiomaWS.onopen = () => console.log("✅ Axioma COR-Bridge WS подключён");

    axiomaWS.onmessage = (event) => {
        console.log("📩 WS сообщение получено:", event.data);

        try {
            const raw = JSON.parse(event.data);
           // console.log("🧩 WS JSON распарсен:", raw);

            const hex = raw?.data?.hex_response;
            if (!hex) {
                console.warn("⚠️ Нет data.hex_response в сообщении", raw);
                return;
            }

          //  console.log("🔢 hex_response:", hex);

            // Универсальный парсер
            const parsed = parseAxiomaHex(hex);

            if (!parsed) {
                console.warn("⚠️ Данные не распознаны");
                return;
            }

            // Обновляем lastData
            window.lastData = { ...window.lastData, ...parsed };
            console.log("📊 lastData обновлён:", window.lastData);
            updateUIByData(window.lastData);

        } catch (e) {
            console.error("❌ Ошибка обработки WS:", e, event.data);
        }
    };

    axiomaWS.onerror = (err) => console.error("❌ Axioma WS ошибка:", err);

    axiomaWS.onclose = (e) => {
        console.warn("🔌 Axioma WS закрыт", {
            code: e.code,
            reason: e.reason,
            wasClean: e.wasClean
        });

        axiomaWS = null;
        console.log("⏳ Переподключение через 3 секунды...");
        setTimeout(() => startAxiomaCORBridgeWS(objectData), 3000);
    };
}

function stopAxiomaWS() {
    if (axiomaWS) {
        console.log("🛑 Остановка Axioma WS");
        axiomaWS.close();
        axiomaWS = null;
    }
}

/**
 * Универсальный парсер для разных типов данных
 */
function parseAxiomaHex(hexResponse) {
    if (!hexResponse) return null;

    const ascii = hexToAscii(hexResponse).trim();
    console.log("🔤 ASCII вход:", ascii);

    // Чистим управляющие символы
    const clean = ascii.replace(/[()\r\n]/g, "");

    // Определяем тип данных
    if (clean.startsWith("E") || clean.startsWith("D")) {
        // QFLAG
        return parseQFLAG(clean);
    } else if (ascii.startsWith("(")) {
        // QPIGS
        return parseQPIGS(hexResponse);
    } else {
        console.warn("❌ Неизвестный формат данных:", clean);
        return null;
    }
}

/**
 * Парсер QFLAG
 */
function parseQFLAG(ascii) {
    // Пример входа: EADJDKUVXYZ
    // E — включено, D — выключено, буквы после них — что именно

    if (!ascii || ascii.length < 2) return null;

    const flagsMap = {
        A: "silenceBuzzer",
        B: "overloadBypass",
        J: "powerSaving",
        K: "lcdEscape",
        U: "overloadRestart",
        V: "overTempRestart",
        X: "backlight",
        Y: "alarmOnPrimaryInterrupt",
        Z: "faultCodeRecord"
    };

    const result = {};

    // Берём последовательность после E или D
    const regex = /([ED])([A-Z])/g;
    let match;
    while ((match = regex.exec(ascii)) !== null) {
        const status = match[1] === "E"; // E = true, D = false
        const letter = match[2];
        if (flagsMap[letter]) result[flagsMap[letter]] = status;
    }

    console.log("✅ QFLAG parsed:", result);
    return result;
}

/**
 * Парсер QPIGS (оставлен без изменений)
 */
function parseQPIGS(hexResponse) {
    console.log("➡️ parseQPIGS вход:", hexResponse);

    const ascii = hexToAscii(hexResponse).trim();
    console.log("🔤 ASCII:", ascii);

    if (!ascii.startsWith("(")) {
        console.warn("❌ Не QPIGS:", ascii);
        return null;
    }

    const clean = ascii.replace(/[()]/g, "");
    const parts = clean.split(/\s+/);
    console.log("🧩 QPIGS parts:", parts);

    if (parts.length < 17) {
        console.warn("❌ Недостаточно полей QPIGS:", parts.length, parts);
        return null;
    }

    const apparentPower = parseFloat(parts[4]); // VA
    const outputVoltage = parseFloat(parts[2]) || 1; // V, защита от 0
    const outputCurrent = apparentPower / outputVoltage; // A

    const result = {
        inputVoltage: parseFloat(parts[0]),
        inputFrequency: parseFloat(parts[1]),
        outputVoltage: outputVoltage,
        outputFrequency: parseFloat(parts[3]),
        outputApparentPower: apparentPower,
        outputActivePower: parseInt(parts[5]),
        loadPercent: parseInt(parts[6]),
        busVoltage: parseInt(parts[7]),
        batteryVoltage: parseFloat(parts[8]),
        batteryChargeCurrent: parseInt(parts[9]),
        batterySOC: parseInt(parts[10]),
        inverterTemp: parseInt(parts[11]),
        pvChargeCurrent: parseInt(parts[12]),
        pvVoltage: parseFloat(parts[13]),
        batteryVoltageSCC: parseFloat(parts[14]),
        batteryDischargeCurrent: parseInt(parts[15]),
        statusBits: parts[16],
        outputCurrent: outputCurrent
    };

    console.log("✅ QPIGS результат:", result);


     // --- Добавляем обновление индикатора нагрузки ---
    if ( result.outputApparentPower != null) {
        const INVERTER_MAX_POWER = 11000; // можно вынести глобально
        updatePowerByName(
            "Load",
            PowerToIndicator(result.outputApparentPower, INVERTER_MAX_POWER)
        );
        const loadIndicatorLabel = document.querySelector("#loadIndicatorLabel");
        if (loadIndicatorLabel) {
            loadIndicatorLabel.textContent = formatPowerLabel(result.outputApparentPower, "load");
        }
    }


    return result;
}



